# Dark mode Mastodon pattern

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/GRGmvbo](https://codepen.io/t_afif/pen/GRGmvbo).

